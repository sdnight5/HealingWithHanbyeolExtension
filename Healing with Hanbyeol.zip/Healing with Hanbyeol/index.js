setInterval(()=>{

let imgs = document.querySelectorAll('img');
imgs.forEach((a,i)=>{
    a.src = 'https://shiftpsh-blog.s3.amazonaws.com/uploads/2022/04/listing216.png';
});

},100); 